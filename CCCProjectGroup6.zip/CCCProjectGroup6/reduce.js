const arr = [1,2,3,4,5,6,7];
const sum = arr.reduce(function(acc,cur,index,arry){
  console.log(acc,cur,index,arry);
  return acc + cur ;
});