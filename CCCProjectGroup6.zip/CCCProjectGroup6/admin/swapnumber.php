<?php
  $a = 2;
  $b = 3;
  $b = $a + $b;
  $a = $b - $a;
  $b = $b - $a;
  echo "a = ".$a."<br/>";
  echo "b = ".$b;

  
    interface Demo{
        const NAME = 'ccc';
        const URL = 'www.google.com';
        function fun1();
        function fun2($a,$b,$c);
    }

    class Website implements Demo{
        public function fun1(){
            echo self::NAME.'<br>';
            echo self::URL.'<br/>';
        }
        public function fun2($a,$b,$c){
            echo $a * $b * $c /100;
        }
    }

    $obj = new Website();
    $obj -> fun1();
    $obj -> fun2(1,2,3);


?>