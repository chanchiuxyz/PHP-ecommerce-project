
<?php
     
     
     require_once('checkout.php'); 
     $guestCheckout = true;
     header("location:guest-billing-shiping.php");
   
?>